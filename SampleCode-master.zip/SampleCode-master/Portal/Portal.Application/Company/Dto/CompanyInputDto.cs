﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Application.Dto
{
    public class CompanyInputDto
    {
    }
}
