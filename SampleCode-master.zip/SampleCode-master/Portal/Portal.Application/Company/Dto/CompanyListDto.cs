﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Portal.Application.Dto
{
    public class CompanyListDto
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
